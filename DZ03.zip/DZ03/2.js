function Grettings() {
    let name = prompt('Как вас зовут?');
    msg = `Привет, ${name}!!`
    alert(msg)
};

Grettings();
console.log(msg);